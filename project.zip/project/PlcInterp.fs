

module PlcInterp

open Absyn
open Environ

let rec eval (e : expr) (env : plcVal env) : plcVal =
    match e with
    | ConI i -> IntV i
    | ConB b -> BoolV b
    | Var x  -> lookup env x
    | ESeq(_) ->SeqV [] 


    | Prim1 (op, e1) ->
      let v1 = eval e1 env in
      match (op, v1) with
      | ("[]", SeqV [])-> SeqV [] 
      | ("-", IntV i) -> IntV (- i)
      | ("!", BoolV b) -> BoolV (not b)
      | ("print", v1) -> v1
      | ("ise", SeqV i) -> 
        match i with 
        |[] -> BoolV(true)
        |_ ->  BoolV(false) 
      | ("hd", SeqV i) -> if i.IsEmpty then failwith"empty sequence" else i.Head
      | ("tl", SeqV i) -> if i.IsEmpty then failwith"empty sequence" else SeqV i.Tail
      | _   -> failwith "Impossible"

    | Prim2 (op, e1, e2) ->
      let v1 = eval e1 env in
      let v2 = eval e2 env in
      match (op, v1, v2) with
      | ("&&", BoolV i1, BoolV i2) -> BoolV (i1 && i2)
      | ("::", a, SeqV b) -> SeqV(a :: b)
      | ("=", _, _) -> BoolV (v1 = v2)
      | ("!=", _, _) -> BoolV (v1 <> v2)
      | ("+", IntV i1, IntV i2) -> IntV (i1 + i2)
      | ("-", IntV i1, IntV i2) -> IntV (i1 - i2)
      | ("*", IntV i1, IntV i2) -> IntV (i1 * i2)
      | ("/", IntV i1, IntV i2) -> IntV (i1 / i2)
      | ("<", IntV i1, IntV i2) -> BoolV (i1 < i2)
      | ("<=", IntV i1, IntV i2) -> BoolV (i1 <= i2)
      | (";", a, b) -> b
      | _   -> failwith "Impossible"

    | Let (x, e1, e2) ->
      let v = eval e1 env in
      let env2 = (x, v) :: env in
      eval e2 env2
    
    | Letrec (f, _, x, _, e1, e2) ->
        let env2 = (f, Clos(f, x, e1, env)) :: env in
        eval e2 env2

    | Match (e1, eoel) ->
       let v1 = eval e1 env in
       let rec fd v eoel =
           match eoel with
               | [] -> failwith "match with empty eoel"
               | (Some(e2), e) :: tl -> if v1 = eval e2 env then eval e env else fd v tl
               | (None,e):: tl -> eval e env
       in fd v1 eoel

    
    | If (e1, e2, e3) ->
      let v1 = eval e1 env in
      match v1 with
      | BoolV true  -> eval e2 env
      | BoolV false -> eval e3 env
      | _ -> failwith "Impossible"


    | Call (f, e) ->
      let c = eval f env in
      match c with
      | Clos (f, x, e1, fenv) ->
        let v = eval e env in
        let env1 = (x, v) :: (f, c) :: fenv in
        eval e1 env1
      | _ -> failwith "eval Call: not a function"

    | List es -> ListV (List.map (fun e -> eval e env) es)

    | Item (n, e1) ->
      match eval e1 env with
      | ListV vs -> List.item (n - 1) vs
      | _ -> failwith "Impossible"


    | Anon (t, x, e) -> Clos("", x, e, env)



   

